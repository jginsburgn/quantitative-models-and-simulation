package mx.itesm.csf.preventec;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by sebastiangalguera on 4/29/18.
 */

public class PathFinderRequest extends StringRequest {
    private static final String PATHFINDER_REQUEST_URL="http://10.49.73.7:3000";
    private Map<String, String> params;

    @Override
    public String getBodyContentType() {
        return "application/x-www-form-urlencoded; charset=UTF-8";
    }

    public PathFinderRequest(String vertexID, Response.Listener<String> listener){
        super(Method.POST, PATHFINDER_REQUEST_URL, listener, null);
        params = new HashMap<>();
        params.put("vertexID", vertexID);
    }

    @Override
    public Map<String, String> getParams(){
        return params;
    }
}
