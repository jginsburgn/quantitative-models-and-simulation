package mx.itesm.csf.preventec;

import android.content.Context;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.util.ArrayList;

/**
 * Created by sebastiangalguera on 4/29/18.
 */

public class RouteCardAdapter extends RecyclerView.Adapter<RouteCardAdapter.ViewHolder> {

    // Hacer el arreglo de rutas
    ArrayList<Route> routeList = null;
    Context context = null;


    public RouteCardAdapter(Context context, ArrayList<Route> routeList) {
        this.context = context;
        this.routeList = routeList;
    }

    @Override
    public RouteCardAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View childView = LayoutInflater.from(parent.getContext()).inflate(R.layout.route_card_layout, parent, false);
        return new ViewHolder(childView);
    }


    @Override
    public void onBindViewHolder(final RouteCardAdapter.ViewHolder holder, final int position) {

        final Route route = routeList.get(position);

        // Obtener todos los campos que queramos aquí
        String vertexID = route.getVertexID();
        String nextStep = route.getNextStep();
        String delay = route.getDelay();
        holder.vertexID.setText(vertexID);
        holder.nextStep.setText(nextStep);
        holder.delay.setText(delay);
    }


    @Override
    public int getItemCount() {
        return routeList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder{

        private TextView vertexID, nextStep, delay;
        private CardView card;

        public ViewHolder(View elementView) {
            super(elementView);

            card = (CardView) elementView.findViewById(R.id.RouteCardView);

            vertexID = (TextView) elementView.findViewById(R.id.vertexIDTextEdit);
            nextStep = (TextView) elementView.findViewById(R.id.routeTextEdit);
            delay = (TextView) elementView.findViewById(R.id.delayTextEdit);

        }
    }
}
