package mx.itesm.csf.preventec;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class PathFinder extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        supportRequestWindowFeature(Window.FEATURE_ACTION_BAR_OVERLAY);
        setContentView(R.layout.activity_path_finder);

        // Obtener el valor de la caja de texto y el botón
        final Button btnSend = (Button) findViewById(R.id.btn_send);
        final Button btnBack = (Button) findViewById(R.id.btn_back);
        final EditText inputID = (EditText) findViewById(R.id.editText_id_field);

        // Go to Main Activity
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PathFinder.this, MainActivity.class);
                startActivity(intent);
            }
        });

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // obtener los campos e insertarlos en variables
                final String vertexID = inputID.getText().toString();

                // si no se llenaron todos los campos
                if(vertexID.isEmpty()){
                    Context context = getApplicationContext();
                    CharSequence text = "Información Incompleta.";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }else{

                    // si se llenaron todos, comenzar un response listener
                    Response.Listener<String> respListener = new Response.Listener<String>(){
                        @Override
                        public void onResponse(String response) {
                            try{
                                // se obtiene un json object
                                JSONObject jsonResp = new JSONObject(response);

                                String gotJson = jsonResp.getString("code");

                                // si se logró obtener el json
                                if (gotJson.equals("success")){
                                    Log.d("HOLA", "onResponse: verga");
                                    JSONArray path = jsonResp.getJSONArray("path");
                                    Intent intent = new Intent(PathFinder.this, PathNavigation.class);
                                    intent.putExtra("path", path.toString());
                                    intent.putExtra("vertexID", vertexID);
                                    PathFinder.this.startActivity(intent);
                                }else{
                                    AlertDialog.Builder builder= new AlertDialog.Builder(PathFinder.this);
                                    builder.setMessage("Path Finding Failed")
                                            .setNegativeButton("Retry", null)
                                            .create()
                                            .show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    };
                    // se hace el register request al cual se le envían las variables capturadas
                    PathFinderRequest registerRequest = new PathFinderRequest(vertexID, respListener);
                    RequestQueue queue = Volley.newRequestQueue(PathFinder.this);
                    queue.add(registerRequest);

                }
            }
        });
    }
}
