package mx.itesm.csf.preventec;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import java.util.Timer;
import java.util.TimerTask;

public class Splash extends AppCompatActivity {

    // Establecer un tiempo a esperar
    private long time = 5000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        // Hacer un timertask que incluya una función run que enviará un intent
        TimerTask splashTask = new TimerTask(){
            public void run(){
                finish();
                Intent splash_intent = new Intent().setClass(Splash.this, MainActivity.class);
                startActivity(splash_intent);
            }
        };
        // Generar un timer y pasarle los parámetros del tiempo y el timertask
        Timer timer = new Timer();
        timer.schedule(splashTask, time);
    }
}
