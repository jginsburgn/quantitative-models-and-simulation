package mx.itesm.csf.preventec;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class PathNavigation extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ArrayList<Route> routeList;
    private RouteCardAdapter routeCardAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        supportRequestWindowFeature(Window.FEATURE_ACTION_BAR_OVERLAY);
        setContentView(R.layout.activity_path_navigation);

        String jsonArray, vertexID;

        TextView id = (TextView) findViewById(R.id.vertex_textView);
        TextView eta = (TextView) findViewById(R.id.eta_textView);

        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if(extras == null) {
                jsonArray = "";
                vertexID = "";
            } else {
                jsonArray = extras.getString("path");
                vertexID = extras.getString("vertexID");
            }
        } else {
            jsonArray = (String) savedInstanceState.getSerializable("path");
            vertexID = (String) savedInstanceState.getSerializable("vertexID");
        }

        id.setText(vertexID);
        try {
            JSONArray array = new JSONArray(jsonArray);

            recyclerView = (RecyclerView) findViewById(R.id.navigation_recyclerView);
            recyclerView.setHasFixedSize(true);
            recyclerView.setLayoutManager( new LinearLayoutManager(this));

            routeList = new ArrayList<>();
            routeCardAdapter = new RouteCardAdapter(this, routeList);
            recyclerView.setAdapter(routeCardAdapter);

            fillArray(array);
            eta.setText(String.valueOf(calculateETA(array)).substring(0,4));

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private double calculateETA(JSONArray response){
        double delay = 0;
        try {
            JSONObject obj;
            for (int i = 0; i < response.length(); i++) {
                Route route = new Route();
                obj = (JSONObject) response.get(i);
                delay += obj.getDouble("delay");
            }
            return delay;
        } catch (JSONException e) {
            Context context = getApplicationContext();
            CharSequence text = "Error.";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
            return 0;
        }
    }

    private void fillArray(JSONArray response){
        try {
            JSONObject obj;
            for (int i = 0; i < response.length(); i++) {
                Route route = new Route();
                obj = (JSONObject) response.get(i);
                route.setVertexID(obj.getString("id"));
                route.setNextStep(obj.getString("nextStep"));
                route.setDelay(obj.getString("delay").substring(0,4));
                routeList.add(route);
            }
            routeCardAdapter.notifyDataSetChanged();
        } catch (JSONException e) {
            Context context = getApplicationContext();
            CharSequence text = "Error.";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
    }
}
