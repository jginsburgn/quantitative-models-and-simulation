package mx.itesm.csf.preventec;

import android.content.Intent;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.Window;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        supportRequestWindowFeature(Window.FEATURE_ACTION_BAR_OVERLAY);
        setContentView(R.layout.activity_main);

        // crear menu y un toggle para abrirlo
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        mToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.string.open, R.string.close);
        mDrawerLayout.addDrawerListener(mToggle);

        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Principal");

        NavigationView mNavigationView = (NavigationView) findViewById(R.id.nav_menu);
        mNavigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(final MenuItem menuItem) {

                int id = menuItem.getItemId();
                switch (id) {
                    case R.id.nav_routes:
                        Intent pathFinderIntent = new Intent(MainActivity.this, PathFinder.class);
                        MainActivity.this.startActivity(pathFinderIntent);
                        return true;
                    case R.id.nav_tips:
                        Intent safetyTipsIntent = new Intent(MainActivity.this, SafetyTips.class);
                        MainActivity.this.startActivity(safetyTipsIntent);
                        return true;
                    case R.id.nav_zones:
                        Intent safeZonesIntent = new Intent(MainActivity.this, SafeZones.class);
                        MainActivity.this.startActivity(safeZonesIntent);
                        return true;
                    case R.id.nav_main:
                        Intent mainActivityIntent = new Intent(MainActivity.this, MainActivity.class);
                        MainActivity.this.startActivity(mainActivityIntent);
                        return true;
                    default:
                        return true;
                }
            }
        });

    }
}
