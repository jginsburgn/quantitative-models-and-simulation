package mx.itesm.csf.preventec;

/**
 * Created by sebastiangalguera on 4/29/18.
 */

public class Route {
    public String vertexID, nextStep, delay;
    public String getVertexID(){
        return vertexID;
    }
    public String getNextStep() {
        return nextStep;
    }
    public String getDelay() {
        return delay;
    }
    public void setVertexID(String vertexID){
        this.vertexID = vertexID;
    }
    public void setNextStep(String nextStep) {
        this.nextStep = nextStep;
    }
    public void setDelay(String delay){
        this.delay = delay;
    }
}
